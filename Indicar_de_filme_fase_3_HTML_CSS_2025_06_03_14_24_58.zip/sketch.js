function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
function setup() {
    createCanvas(windowWidth, windowHeight); // Canvas ocupa toda a tela
    noStroke(); // Sem bordas nas figuras

    // Definir o fundo como preto
    background(0);

    // Criar os filmes no catálogo
    const movies = [
        {
            title: "Spider-Man: Através do Aranhaverso",
            description: "O Homem-Aranha precisa enfrentar uma ameaça que pode destruir todas as dimensões.",
            url: "https://www.youtube.com/embed/gt_fAE1Eg2Q"
        },
        {
            title: "Batman: O Cavaleiro das Trevas",
            description: "Batman deve enfrentar o Coringa em uma batalha pela justiça em Gotham City.",
            url: "https://www.youtube.com/embed/EXeTwQWrcwY"
        },
        {
            title: "Vingadores: Ultimato",
            description: "Os Vingadores devem unir forças para enfrentar a maior ameaça que o universo já conheceu.",
            url: "https://www.youtube.com/embed/TcMBFSGVi1c"  // Link para o trailer de Vingadores: Ultimato
        }
    ];

    // Adicionar o título "FILMES" no topo da tela
    textSize(48);
    fill(255, 204, 0); // Cor amarela
    textAlign(CENTER, TOP); // Alinhar o texto ao centro e ao topo
    text("FILMES", windowWidth / 2, 30); // Coloca "FILMES" no topo da tela

    // Exibir os filmes na tela, em linha horizontal, mas ajustando o espaçamento
    let totalWidth = movies.length * 600; // Largura total dos filmes (600px de cada)
    let spacing = (windowWidth - totalWidth) / 2; // Espaçamento calculado para centralizar os filmes

    let yPosition = 150; // Todos os filmes estarão um pouco abaixo do título (y = 150)
    for (let i = 0; i < movies.length; i++) {
        let movie = movies[i];
        let xPosition = spacing + (i * 600); // Posição x ajustada com o espaçamento calculado

        // Desenhar título do filme
        textSize(18);
        fill(255, 204, 0);
        text(movie.title, xPosition + 20, yPosition); // Adicionando um pequeno deslocamento em x

        // Descrição do filme
        textSize(12);
        fill(255);
        text(movie.description, xPosition + 20, yPosition + 30); // Descrição logo abaixo do título

        // Adicionar iframe de vídeo
        createIframe(movie.url, xPosition, yPosition + 50);
    }
}

function draw() {
    // Nada a desenhar aqui, pois o fundo está fixo e não há animações ou interação necessária
}

// Função para criar o iframe do YouTube
function createIframe(url, x, y) {
    let iframe = createElement('iframe');
    iframe.attribute('width', '560');
    iframe.attribute('height', '315');
    iframe.attribute('src', url);
    iframe.attribute('frameborder', '0');
    iframe.attribute('allow', 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share');
    iframe.position(x, y);

    // Garantir que o iframe não tenha borda e fique bem visível
    iframe.style('border', 'none');  // Remove qualquer borda que possa estar causando o efeito "fosco"
    iframe.style('box-shadow', '0 0 10px rgba(255, 255, 255, 0.3)');  // Leve sombra para dar destaque sem "ficar fosco"
}

